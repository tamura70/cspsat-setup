================================================================
README for tool programs of Sugar (A SAT-based Constraint Solver) 
http://bach.istc.kobe-u.ac.jp/sugar/

See individual files for more details.

jss/
	Job-Shop Scheduling Problems

oss/
	Open-Shop Scheduling Problems

tdsp/
	Two-dimensional Strip Packing Problems

gcp/
	Graph Coloring Problems

misc/arithm.pl
	Cryptarithmetic Puzzles

misc/bibd.pl
	Balanced Incomplete Block Design Problems

misc/golombRuler.pl
	Golomb Ruler Problems

misc/knightTour.pl
	Knight's Tour Problems

misc/magicSquare.pl
	Magic Square Problems

misc/nqueens.pl
	N-Queens Problems

misc/socialGolfer.pl
	Social Golfer Problems

================================================================
